document.addEventListener('DOMContentLoaded', () => {
	const experiencesEl = document.getElementById('experiences');
	const educationsEl = document.getElementById('educations');
	const addExpBtn = document.getElementById('add-experience');
	const addEduBtn = document.getElementById('add-education');
	const skillInput = document.getElementById('skill-input');
	const skillsEl = document.getElementById('skills');
	const previewBtn = document.getElementById('preview-btn');
	const printBtn = document.getElementById('print-btn');
	const previewArea = document.getElementById('cv-preview');

	// Theme toggle elements and helpers
	const themeToggle = document.getElementById('theme-toggle');

	function applyTheme(theme) {
		const html = document.documentElement;
		if (theme === 'dark') {
			html.classList.add('theme-dark');
			if (themeToggle) themeToggle.setAttribute('aria-pressed', 'true');
			if (themeToggle) themeToggle.textContent = '☀️';
		} else {
			html.classList.remove('theme-dark');
			if (themeToggle) themeToggle.setAttribute('aria-pressed', 'false');
			if (themeToggle) themeToggle.textContent = '🌙';
		}
		try { localStorage.setItem('mycv-theme', theme); } catch (e) { /* ignore */ }
	}

	function initTheme() {
		let stored = null;
		try { stored = localStorage.getItem('mycv-theme'); } catch (e) { stored = null; }
		if (stored) { applyTheme(stored); return; }
		// fallback to prefers-color-scheme
		if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
			applyTheme('dark');
		} else {
			applyTheme('light');
		}
	}

	if (themeToggle) {
		themeToggle.addEventListener('click', () => {
			const isPressed = themeToggle.getAttribute('aria-pressed') === 'true';
			applyTheme(isPressed ? 'light' : 'dark');
		});
	}

	// initialize theme early
	initTheme();

	const skills = [];

	function createExperienceItem(data = {}) {
		const wrapper = document.createElement('div');
		wrapper.className = 'exp-item entry-card';
		wrapper.innerHTML = `
			<div class="form-grid">
			  <div class="form-row">
			    <label class="field-label">Company</label>
			    <input class="neon-input" data-key="company" placeholder="Company" value="${data.company||''}">
			  </div>
			  <div class="form-row">
			    <label class="field-label">Position</label>
			    <input class="neon-input" data-key="position" placeholder="Position" value="${data.position||''}">
			  </div>
			  <div class="form-row">
			    <label class="field-label">Start</label>
			    <input class="neon-input" data-key="start" placeholder="Start (yyyy)" value="${data.start||''}">
			  </div>
			  <div class="form-row">
			    <label class="field-label">End</label>
			    <input class="neon-input" data-key="end" placeholder="End (yyyy or Present)" value="${data.end||''}">
			  </div>
			  <div class="form-row field-full">
			    <label class="field-label">Description</label>
			    <textarea class="neon-input" data-key="desc" rows="2" placeholder="Short description">${data.desc||''}</textarea>
			  </div>
			</div>
			<div class="entry-actions"><button class="neon-button remove-btn" type="button">Remove</button></div>
		`;

		const removeBtn = wrapper.querySelector('.remove-btn');
		removeBtn.addEventListener('click', () => wrapper.remove());
		experiencesEl.appendChild(wrapper);
		return wrapper;
	}

	function createEducationItem(data = {}) {
		const wrapper = document.createElement('div');
		wrapper.className = 'edu-item entry-card';
		wrapper.innerHTML = `
			<div class="form-grid">
			  <div class="form-row">
			    <label class="field-label">School / Institution</label>
			    <input class="neon-input" data-key="school" placeholder="School / Institution" value="${data.school||''}">
			  </div>
			  <div class="form-row">
			    <label class="field-label">Degree / Program</label>
			    <input class="neon-input" data-key="degree" placeholder="Degree / Program" value="${data.degree||''}">
			  </div>
			  <div class="form-row">
			    <label class="field-label">Start</label>
			    <input class="neon-input" data-key="ed-start" placeholder="Start (yyyy)" value="${data.start||''}">
			  </div>
			  <div class="form-row">
			    <label class="field-label">End</label>
			    <input class="neon-input" data-key="ed-end" placeholder="End (yyyy)" value="${data.end||''}">
			  </div>
			</div>
			<div class="entry-actions"><button class="neon-button remove-btn" type="button">Remove</button></div>
		`;

		const removeBtn = wrapper.querySelector('.remove-btn');
		removeBtn.addEventListener('click', () => wrapper.remove());
		educationsEl.appendChild(wrapper);
		return wrapper;
	}

	addExpBtn.addEventListener('click', () => createExperienceItem());
	addEduBtn.addEventListener('click', () => createEducationItem());

	skillInput.addEventListener('keydown', (e) => {
		if (e.key === 'Enter') {
			e.preventDefault();
			const v = skillInput.value.trim();
			if (!v) return;
			skills.push(v);
			renderSkills();
			skillInput.value = '';
		}
	});

	function renderSkills() {
		skillsEl.innerHTML = '';
		skills.forEach((s, i) => {
			const el = document.createElement('span');
			el.className = 'tag';
			el.textContent = s;
			el.title = 'Click to remove';
			el.addEventListener('click', () => { skills.splice(i, 1); renderSkills(); });
			skillsEl.appendChild(el);
		});
	}

	function gatherForm() {
		return {
			fullname: (document.getElementById('fullname') || {}).value || '',
			title: (document.getElementById('title') || {}).value || '',
			email: (document.getElementById('email') || {}).value || '',
			phone: (document.getElementById('phone') || {}).value || '',
			profile: (document.getElementById('profile') || {}).value || '',
			experiences: Array.from(document.querySelectorAll('.exp-item')).map(node => ({
				company: (node.querySelector('input[data-key="company"]')||{}).value || '',
				position: (node.querySelector('input[data-key="position"]')||{}).value || '',
				start: (node.querySelector('input[data-key="start"]')||{}).value || '',
				end: (node.querySelector('input[data-key="end"]')||{}).value || '',
				desc: (node.querySelector('textarea[data-key="desc"]')||{}).value || ''
			})),
			education: Array.from(document.querySelectorAll('.edu-item')).map(node => ({
				school: (node.querySelector('input[data-key="school"]')||{}).value || '',
				degree: (node.querySelector('input[data-key="degree"]')||{}).value || '',
				start: (node.querySelector('input[data-key="ed-start"]')||{}).value || '',
				end: (node.querySelector('input[data-key="ed-end"]')||{}).value || ''
			})),
			skills: skills.slice()
		};
	}

	function renderPreview() {
		const data = gatherForm();
		previewArea.innerHTML = '';

		const header = document.createElement('div');
		header.className = 'cv-header';
		header.innerHTML = `
			<div>
				<div class="cv-name">${data.fullname || 'Your Name'}</div>
				<div class="cv-title">${data.title || ''}</div>
			</div>
			<div class="cv-contact">
				<div>${data.email || ''}</div>
				<div>${data.phone || ''}</div>
			</div>
		`;
		previewArea.appendChild(header);

		// if a photo was uploaded, append it to the header
		if (photoDataUrl) {
			const img = document.createElement('img');
			img.src = photoDataUrl;
			img.className = 'cv-photo';
			header.appendChild(img);
		}

		if (data.profile) {
			const sec = document.createElement('div'); sec.className = 'cv-section';
			sec.innerHTML = `<h4>Profile</h4><div>${escapeHtml(data.profile)}</div>`;
			previewArea.appendChild(sec);
		}

		if (data.experiences.length) {
			const sec = document.createElement('div'); sec.className = 'cv-section';
			sec.innerHTML = `<h4>Work Experience</h4>`;
			data.experiences.forEach(e => {
				const it = document.createElement('div'); it.className = 'cv-item';
				it.innerHTML = `<div><strong>${escapeHtml(e.position)}</strong> — <em>${escapeHtml(e.company)}</em></div><div class="cv-meta">${escapeHtml(e.start)} — ${escapeHtml(e.end)}</div><div>${escapeHtml(e.desc)}</div>`;
				sec.appendChild(it);
			});
			previewArea.appendChild(sec);
		}

		if (data.education.length) {
			const sec = document.createElement('div'); sec.className = 'cv-section';
			sec.innerHTML = `<h4>Education</h4>`;
			data.education.forEach(e => {
				const it = document.createElement('div'); it.className = 'cv-item';
				it.innerHTML = `<div><strong>${escapeHtml(e.degree)}</strong> — <em>${escapeHtml(e.school)}</em></div><div class="cv-meta">${escapeHtml(e.start)} — ${escapeHtml(e.end)}</div>`;
				sec.appendChild(it);
			});
			previewArea.appendChild(sec);
		}

		if (data.skills.length) {
			const sec = document.createElement('div'); sec.className = 'cv-section';
			sec.innerHTML = `<h4>Skills</h4><div>${data.skills.map(s=>`<span class="tag">${escapeHtml(s)}</span>`).join(' ')}</div>`;
			previewArea.appendChild(sec);
		}
	}

	previewBtn.addEventListener('click', renderPreview);
	printBtn.addEventListener('click', () => { renderPreview(); window.print(); });

	// Photo handling
	const photoInput = document.getElementById('photo');
	let photoDataUrl = null;
	if (photoInput) {
		photoInput.addEventListener('change', (e) => {
			const file = e.target.files && e.target.files[0];
			if (!file) { photoDataUrl = null; return; }
			const reader = new FileReader();
			reader.onload = () => { photoDataUrl = reader.result; };
			reader.readAsDataURL(file);
		});
	}

	// Demo / fill button: populate form with sample data for testing
	const fillDemoBtn = document.getElementById('fill-demo-btn');
	function fillDemo() {
		try {
			document.getElementById('fullname').value = 'Jane Doe';
			document.getElementById('title').value = 'Frontend Developer';
			document.getElementById('email').value = 'jane.doe@example.com';
			document.getElementById('phone').value = '+44 7700 900123';
			document.getElementById('profile').value = 'Product-focused front-end developer with 5+ years building accessible web applications and component libraries.';

			// clear existing dynamic entries
			experiencesEl.innerHTML = '';
			educationsEl.innerHTML = '';
			skills.length = 0;

			// create sample experiences
			createExperienceItem({ company: 'Acme Corp', position: 'Senior Frontend Developer', start: '2019', end: 'Present', desc: 'Led UI rebuild, improved performance and accessibility.' });
			createExperienceItem({ company: 'Web Works', position: 'Frontend Developer', start: '2016', end: '2019', desc: 'Built responsive interfaces and design system components.' });

			// create sample educations
			createEducationItem({ school: 'University of Example', degree: 'BSc Computer Science', start: '2012', end: '2015' });
			createEducationItem({ school: 'Example College', degree: 'Diploma in Design', start: '2010', end: '2012' });

			// sample skills
			skills.push('JavaScript', 'HTML', 'CSS', 'React', 'Accessibility');
			renderSkills();

			// small inline SVG avatar as fallback (data URL)
			const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="300" height="300"><rect width="100%" height="100%" fill="#dfefe6"/><circle cx="150" cy="100" r="55" fill="#9bbfa6"/><rect x="70" y="190" width="160" height="60" rx="10" fill="#bcdcc8"/></svg>`;
			photoDataUrl = 'data:image/svg+xml;base64,' + btoa(svg);

			// render preview to show the result
			renderPreview();
		} catch (err) {
			console.error('Demo fill failed', err);
		}
	}

	if (fillDemoBtn) fillDemoBtn.addEventListener('click', fillDemo);

	// Reset button: clear form, dynamic entries, skills, photo and preview
	const resetBtn = document.getElementById('reset-btn');
	function resetForm() {
		try {
			// clear main inputs
			const ids = ['fullname','title','email','phone','profile'];
			ids.forEach(id => { const el = document.getElementById(id); if (el) el.value = ''; });

			// clear dynamic sections
			experiencesEl.innerHTML = '';
			educationsEl.innerHTML = '';

			// clear skills
			skills.length = 0; renderSkills();

			// clear photo
			photoDataUrl = null;
			if (photoInput) try { photoInput.value = ''; } catch(e) { /* ignore */ }

			// clear preview
			if (previewArea) previewArea.innerHTML = '';

			// seed with one empty entry for convenience
			createExperienceItem();
			createEducationItem();
		} catch (err) {
			console.error('Reset failed', err);
		}
	}

	if (resetBtn) resetBtn.addEventListener('click', resetForm);

	// Export PDF using html2pdf.js
	const exportBtn = document.getElementById('export-pdf-btn');
	if (exportBtn) {
		exportBtn.addEventListener('click', async () => {
			renderPreview();
			// small delay to ensure images (photo) are rendered
			await new Promise(r => setTimeout(r, 150));
			const node = document.getElementById('cv-preview');
			const name = (document.getElementById('fullname')||{}).value || 'cv';
			const opt = {
				margin:       [10, 10, 10, 10],
				filename:     `${name.replace(/\s+/g,'_')}.pdf`,
				image:        { type: 'jpeg', quality: 0.95 },
				html2canvas:  { scale: 2, useCORS: true, logging: false },
				jsPDF:        { unit: 'mm', format: 'a4', orientation: 'portrait' }
			};

			html2pdf().set(opt).from(node).save();
		});
	}

	// helper: escape HTML in user text
	function escapeHtml(str) {
		if (!str) return '';
		return String(str)
			.replace(/&/g, '&amp;')
			.replace(/</g, '&lt;')
			.replace(/>/g, '&gt;')
			.replace(/"/g, '&quot;')
			.replace(/'/g, '&#39;');
	}

	// seed with one editable entry each
	createExperienceItem();
	createEducationItem();
});


