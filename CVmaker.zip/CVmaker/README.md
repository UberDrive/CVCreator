# MakeYourCV

Client-side CV builder that generates a printable European-style CV preview.

## What this is

This small web app (pure HTML/CSS/JS) helps you assemble a CV using a form-driven UI. It supports multiple experience and education entries, skill tags, a live preview and printing (save-as-PDF via browser).

## Quick start

- Open `index.html` in a browser (double-click) OR run a lightweight server from the project folder:

```powershell
python -m http.server 8000
# then open http://localhost:8000
```

Recommended: run a local server if your browser blocks local script features.

## Files

- `index.html` — main page with the form and preview.
- `style/style.css` — styles, layout and print rules.
- `JS/script.js` — client logic for dynamic entries, preview and print.

## How to use

 - Upload a personal photo using the `Personal photo` control; the photo will appear in the CV header.
 - Click `Export PDF` to generate and download a PDF directly (uses client-side `html2pdf.js`).

## Development notes
- To generate PDFs programmatically, add a client-side library such as `html2pdf.js`.

## Suggestions & next steps

- Add autosave to `localStorage` so edits persist between sessions.
- Add export/import JSON for sharing or saving drafts.
- Improve the visual template to match Europass exactly.
- Add optional client-side PDF export.

If you'd like, I can add `html2pdf.js` for one-click PDF export or implement autosave. Which do you prefer?